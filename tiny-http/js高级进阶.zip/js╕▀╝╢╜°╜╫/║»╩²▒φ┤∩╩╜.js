
/*	javascript 高级应用 函数表达式	*/


test1();		// 1
function test1(){
	var a = 1;
	alert(a);
}

test();			// test is not a function
var test = function(){
	var a = 11;
	alert(a);
}

//函数声明提升：在执行代码之前会先读取函数声明。这就意味着可以把函数声明放在调用它的语句后面