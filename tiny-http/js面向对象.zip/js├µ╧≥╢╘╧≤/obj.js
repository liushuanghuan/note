


var arr = [];
arr.num = 10; //对象下面的变量，叫对象的属性

//alert(arr.numer);

arr.test = function(){	//对象下面的函数，叫对象的方法
	console.log("123");
}

arr.test();


/************* 创建一个对象 ***********/
var obj = new Object();		//穿件一个空的对象

obj.name = "小明";
obj.showName = function() {		//方法
	console.log(this.name);		//this 指向 obj
}

obj.showName();		//小明


/************** 创建两个或多个对象 *********/
var obj1 = new Object();	//创建一个空的对象
obj1 = "小红";				//属性
obj1.showName = function() {	//方法
	console.log(this.name);
}
obj1.showName();	//小红


var obj2 = new Object();	//创建一个空的对象
obj2.name = "小白";
obj2.showName = function() {
	console.log(this.name);
}
obj2.showName();	//小白


/************* 工厂方式 面向对象中的封装函数**********/
//使用Object函数或对象字面量都可以创建面向对象，但需要创建多个对象时，或产生大量的代码，此时，就可通过工行藏方式类解决这个问题
//工厂方式：封装函数

function createPerson(name, sex, age) {
	var obj = new Object();
	obj.name = name;
	obj.sex = sex;
	obj.age = age;

	obj.showPersonInfo = function() {
		console.log("name:"+this.name+", sex:"+this.sex+", age:"+age);
	};

	return obj;
}

var person1 = createPerson("小明", "famale", 20);
person1.showPersonInfo();

var person2 = createPerson("小红", "male", 18);
person2.showPersonInfo();



/************* 构造函数模式 给一个对象添加方法 **********/
//创建对象用工厂实现，可以传递参数，由于创建对象都是使用Object的原生够着函数来实现的，因此无法识别对象类型

function CreatePerson2(name, age, sex) {
	this.name = name;
	this.age = age;
	this.sex = sex;

	this.showPerson2Info = function() {
		console.log("name:"+this.name+", age:"+age+", sex:"+this.sex);
	}
}

var person3 = new CreatePerson2("Sunny", "17", "male");
person3.showPerson2Info();

var person4 = new CreatePerson2("Jhon", "20", "famale");
person4.showPerson2Info();



/** 
*	使用自定义的够着函数，定义对象类型的属性和方法，与工厂方式的区别：
*		没有显式的创建对象
*		直接将属性和方法赋给this对象
*		没有return语句
*	上例中：CreatePerson构造函数生成的两个对象p1与p2都是CreatePerson的实例
*	虽然构造函数解决了上面工厂方式的问题，但是它一样存在缺点，就是在创建对象时，每个对象都有一套自己的方法，<em>每定义一个函数都实例化了一个对象</em>
*
*/

function CreatePerson3(name) {
	this.name = name;
	this.showName = function() {
		console.log("姓名："+this.name);
	};
}

var p5 = new CreatePerson3("小明");
//p5.showName();
var p6 = new CreatePerson3("小华");
//p6.showName();

console.log(p5.showName == p6.showName);	//false 他们的值相同，但是地址不同


var a = [1, 2, 3];
var b = a;
b.push(5)
console.info("b：", b);		// [1, 2, 3, 5]
console.info("a：", a);		// [1, 2, 3, 5]

var a1 = [1, 2, 3];
var b1 = a1;
b1 = [1, 2, 3, 4];
console.info("b1：", b1);	// [1, 2, 3, 4]
console.info("a1：", a1);	// [1, 2, 3]


/**
*	总结：对象类型的赋值不仅是值的复制，也是引用的传递 
*		对象的引用 p5.showName == p6.showName  返回结果为 false
*
*/

/*********** 原型模式(prototype) 给一类对象添加方法 ***********/
//原型(prototype)：重写对象下面公用的属性或方法，让公用的属性或方法在内存中只存在一份(提高性能)，也就是说所有在原型对象中创建的属性或方法都直接被所有对象实例共享
//原型：类比css中的class
//普通方法：类比css中的style

var arr = [1, 2, 3, 4, 5];
var arr2 = [1, 1, 1, 1, 1];

Array.prototype.sum = function() {	//原型prototype 要写在构造函数的下面
	var result = 0;
	for (var i=0; i<this.length; i++) {
		result += this[i];
	}

	return result;
};

console.log("arr.sum()=", arr.sum());	//15
console.log("arr2.sum()=", arr2.sum());	//5

//原型优先级：如果在实例中添加了一个属性，而该属性与实例原型中的一个属性同名，该属性将会屏蔽原型中的那个属性
//实例1：
var arrFirst = [];
arrFirst.number = 10;
Array.prototype.number = 20;

console.log("arrFirst.number="+arrFirst.number);


//实例2：
Array.prototype.a = 12;		//原型属性
var arrSecond = [1, 2, 3];
console.log("arrSecond.a="+arrSecond.a);

arrSecond.a = 24;	//实例属性
console.log("arrSecond.a="+arrSecond.a);


/************ 工厂方式之原型 **********/
function CreatePerson(name) {	//普通方法
	this.name = name;
}

CreatePerson.prototype.showName = function() {
	console.log(this.name);
};

var pp1 = new CreatePerson("小明");
pp1.showName();

var pp2 = new CreatePerson("小红");
pp2.showName();

console.log(pp1.showName == pp2.showName);

/**
*	总结：由上述例子中：pp1.showName == pp2.showName 的值为true，可见原型解决了构造函数中<em>"每定义一个原型都实例化了一个对象"</em>的问题
**/


/**
*	原型的运用---
*		选项卡实例
*
**/

/**
*		面向对象选项卡
*
**/











